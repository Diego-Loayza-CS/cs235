cat << EOF > first_p2_p8.txt
5 > 3
3 < 4
5 < 7
3 > 2
7 < 8
EOF
python3 ~/projects/btrees/btrees.py first_p2_p8.txt
