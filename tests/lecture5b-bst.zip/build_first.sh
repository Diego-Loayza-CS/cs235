cat << EOF > first.txt
5 > 3
3 < 4
5 < 7
EOF
python3 ~/projects/btrees/btrees.py first.txt
