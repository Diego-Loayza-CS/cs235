#pragma once
#include <iostream>

#define WHERE(x) printf("loc of %s: %p\n", #x, &x)
